# LGMVIP-Projects
Group of projects completed by me as a part of Intern at LGM

<br>

### Author Details:
<p>Name     : MAINAK CHAUDHURI</p>
<p>Position : Web Developer Intern, Let's Grow More</p>
<p>Badges   : LGMVIP</p>
--------------------------------------------------------------


## Project 1
<p>Name       : Paradise Hotels and Resorts</p>
<p>Type       : Frontend </p>
<p>Techs      : HTML5, CSS3, JavaScript(ES6), Bootstrap.</p>
<p>Start Date : 01.07.2021</p>
<p>End Date   : 06.07.2021</p>
<p>Status     : Completed</p>
<p>Demo       :  </p>

https://user-images.githubusercontent.com/64016811/125175808-40c33b00-e1ec-11eb-8b77-2eedb892ec45.mp4



===============================================================

## Project 2
<p>Name       : Ledger</p>
<p>Type       : React based Frontend with API integration</p>
<p>Techs      : ReactJS, NodeJS, Materilize CSS</p>
<p>Start Date : 06.07.2021</p>
<p>End Date   : 11.07.2021</p>
<p>Status     : Completed</p>
<p>Demo       : </p>

https://user-images.githubusercontent.com/64016811/125196986-8712ab80-e279-11eb-963d-17df3b97b278.mp4


===============================================================

## Project 3
<p>Name       : Student Management System</p>
<p>Type       : Full-stack (WAMP)</p>
<p>Techs      : HTML5,CSS3, JavaScript(ES6), Bootstrap, PHP, MySQL, MakeFiles</p>
<p>Start Date : 11.07.2021</p>
<p>End Date   : TDB</p>
<p>Status     : In Progress</p>

---------------------------------------------------------------



